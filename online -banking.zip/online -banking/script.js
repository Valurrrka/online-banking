'use strict';

/////////////////////////////////////////////////
/////////////////////////////////////////////////
// BANKIST APP

// Data
const account1 = {
  owner: 'Jonas Schmedtmann',
  movements: [200, 450, -400, 3000, -650, -130, 70, 1300],
  interestRate: 1.2, // %
  pin: 1111,

  movementsDates: [
    '2022-11-01T13:15:33.035Z',
    '2022-12-23T14:23:21.0604Z',
    '2023-01-12T03:11:45.657Z',
    '2023-02-04T23:34:56.987Z',
    '2023-04-04T12:12:12.654Z',
    '2023-04-12T19:23:32.345Z',
    '2023-05-14T21:45:45.786Z',
    '2023-05-17T11:23:12.234Z',
  ],
  currency: 'EUR',
  locale: 'en-US',
};

const account2 = {
  owner: 'Jessica Davis',
  movements: [5000, 3400, -150, -790, -3210, -1000, 8500, -30],
  interestRate: 1.5,
  pin: 2222,
  movementsDates: [
    '2022-11-01T13:15:33.035Z',
    '2022-12-23T14:23:21.0604Z',
    '2023-01-12T03:11:45.657Z',
    '2023-02-04T23:34:56.987Z',
    '2023-04-04T12:12:12.654Z',
    '2023-04-12T19:23:32.345Z',
    '2023-05-14T21:45:45.786Z',
    '2023-05-17T11:23:12.234Z',
  ],
  currency: 'USD',
  locale: 'ar-SY',
};

const account3 = {
  owner: 'Steven Thomas Williams',
  movements: [200, -200, 340, -300, -20, 50, 400, -460],
  interestRate: 0.7,
  pin: 3333,
};

const account4 = {
  owner: 'Sarah Smith',
  movements: [430, 1000, 700, 50, 90],
  interestRate: 1,
  pin: 4444,
};

const accounts = [account1, account2, account3, account4];

// Elements
const labelWelcome = document.querySelector('.welcome');
const labelDate = document.querySelector('.date');
const labelBalance = document.querySelector('.balance__value');
const labelSumIn = document.querySelector('.summary__value--in');
const labelSumOut = document.querySelector('.summary__value--out');
const labelSumInterest = document.querySelector('.summary__value--interest');
const labelTimer = document.querySelector('.timer');

const containerApp = document.querySelector('.app');
const containerMovements = document.querySelector('.movements');

const btnLogin = document.querySelector('.login__btn');
const btnTransfer = document.querySelector('.form__btn--transfer');
const btnLoan = document.querySelector('.form__btn--loan');
const btnClose = document.querySelector('.form__btn--close');
const btnSort = document.querySelector('.btn--sort');

const inputLoginUsername = document.querySelector('.login__input--user');
const inputLoginPin = document.querySelector('.login__input--pin');
const inputTransferTo = document.querySelector('.form__input--to');
const inputTransferAmount = document.querySelector('.form__input--amount');
const inputLoanAmount = document.querySelector('.form__input--loan-amount');
const inputCloseUsername = document.querySelector('.form__input--user');
const inputClosePin = document.querySelector('.form__input--pin');

const formatMovementday = function (date, locale) {
  const calcDaysPassed = (date1, date2) =>
    Math.round(Math.abs(date2 - date1) / (1000 * 60 * 60 * 24));

  const daysPassed = calcDaysPassed(new Date(), date);
  console.log(daysPassed);

  if (daysPassed === 0) return 'Today';
  if (daysPassed === 1) return 'Yesterday';
  if (daysPassed <= 7) return `${daysPassed} days ago`;
  else {
    return new Intl.DateTimeFormat(locale).format(date);
    //const day = `${date.getDate()}`.padStart(2, '0');
    //const month = `${date.getMonth() + 1}`.padStart(2, '0');
    // const year = date.getFullYear();

    // return `${day}/${month}/${year}`;
  }
};

const formCur = function (value, locale, currency) {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency,
  }).format(value);
};

const movementDisplay = function (acc, sort = false) {
  containerMovements.innerHTML = '';

  const movs = sort
    ? acc.movements.slice().sort((a, b) => a - b)
    : acc.movements;

  movs.forEach(function (mov, i) {
    const type = mov > 0 ? 'deposit' : 'withdrawal';

    const date = new Date(acc.movementsDates[i]);
    const displayDate = formatMovementday(date, acc.locale);

    const formatedMov = formCur(mov, acc.locale, acc.currency);

    const html = ` <div class="movements__row">
          <div class="movements__type movements__type--${type}">${i + 1} ${type}
    <div class="movements__date">${displayDate}</div>
    </div> 
          <div class="movements__value">${formatedMov}</div> </div>`;

    containerMovements.insertAdjacentHTML('afterbegin', html);
  });
};

//movementDisplay(account1.movements);

const calcDisplayBalance = function (acc) {
  const balance = acc.movements.reduce((acc, mov) => acc + mov, 0);

  acc.balance = balance;
  labelBalance.textContent = formCur(acc.balance, acc.locale, acc.currency);
};

const calcDisplaySummary = function (acc) {
  const incomes = acc.movements
    .filter(mov => mov > 0)
    .reduce((acc, mov) => acc + mov, 0);

  labelSumIn.textContent = formCur(incomes, acc.locale, acc.currency);

  const out = acc.movements
    .filter(mov => mov < 0)
    .reduce((acc, mov) => acc + mov, 0);

  labelSumOut.textContent = formCur(Math.abs(out), acc.locale, acc.currency);

  const interest = acc.movements
    .filter(mov => mov > 0)
    .map(deposit => (deposit * acc.interestRate) / 100)
    .filter((int, i, arr) => {
      //console.log(arr);
      return int >= 1;
    })
    .reduce((acc, int) => acc + int, 0);

  labelSumInterest.textContent = formCur(interest, acc.locale, acc.currency);
};

const createUsername = function (accs) {
  accs.forEach(function (acc) {
    acc.username = acc.owner
      .toLowerCase()
      .split(' ')
      .map(function (item) {
        return item[0];
      })
      .join('');
  });
};

createUsername(accounts);

const updateUI = function (acc) {
  //display movements
  movementDisplay(acc);
  //display balance
  calcDisplayBalance(acc);
  //display summary
  calcDisplaySummary(acc);
};
const startLogOutTimer = function () {
  const tick = function () {
    const min = String(Math.trunc(time / 60)).padStart(2, 0);
    const sec = String(time % 60).padStart(2, 0);
    labelTimer.textContent = `${min}:${sec}`;

    if (time === 0) {
      clearInterval(timer);
      labelWelcome.textContent = 'Log in to get started';

      containerApp.style.opacity = 0;
    }
    time--;
  };

  let time = 180;

  tick();
  const timer = setInterval(tick, 1000);
  return timer;
};

let currentAccount, timer;

//fake logged
//currentAccount = account1;
//updateUI(currentAccount);
//containerApp.style.opacity = 100;

//experimeting API
const now = new Date();
labelDate.textContent = new Intl.DateTimeFormat('pl-PL').format(now);

btnLogin.addEventListener('click', function (e) {
  e.preventDefault();
  currentAccount = accounts.find(
    acc => acc.username === inputLoginUsername.value
  );
  console.log(currentAccount);

  if (currentAccount?.pin === Number(inputLoginPin.value)) {
    // welcome message

    labelWelcome.textContent = `Welcome back, ${
      currentAccount.owner.split(' ')[0]
    }`;

    containerApp.style.opacity = 100;

    const now = new Date();

    const options = {
      hour: 'numeric',
      minute: 'numeric',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      week: 'long',
    };

    const locale = navigator.language;
    console.log(locale);

    labelDate.textContent = new Intl.DateTimeFormat(
      currentAccount.locale,
      options
    ).format(now);
    //const day = `${now.getDate()}`.padStart(2, '0');
    // const month = `${now.getMonth() + 1}`.padStart(2, '0');
    // const year = now.getFullYear();
    // const hour = now.getHours();
    // const minute = now.getMinutes();

    // labelDate.textContent = `${day}/${month}/${year}, ${hour}:${minute}`;

    //clear input fields
    inputLoginUsername.value = '';
    inputLoginPin.value = '';

    if (timer) clearInterval(timer);
    timer = startLogOutTimer();
    //update UI
    updateUI(currentAccount);
  }
});

btnTransfer.addEventListener('click', function (e) {
  e.preventDefault();
  const amount = Number(inputTransferAmount.value);
  const receiverAcc = accounts.find(
    acc => acc.username === inputTransferTo.value
  );
  if (
    amount > 0 &&
    receiverAcc &&
    currentAccount.balance >= amount &&
    receiverAcc?.username !== currentAccount.username
  ) {
    inputTransferAmount.value = '';
    inputTransferTo.value = '';

    //doing the transfer
    currentAccount.movements.push(-amount);
    receiverAcc.movements.push(amount);

    //add transfer date
    currentAccount.movementsDates.push(new Date().toISOString());
    receiverAcc.movementsDates.push(new Date().toISOString());

    //update UI
    updateUI(currentAccount);

    clearInterval(timer);
    timer = startLogOutTimer();
  }
});

btnLoan.addEventListener('click', function (e) {
  e.preventDefault();

  const amount = Number(inputLoanAmount.value);

  if (amount > 0 && currentAccount.movements.some(mov => mov >= amount * 0.1)) {
    currentAccount.movements.push(amount);
    currentAccount.movementsDates.push(new Date().toISOString());
    updateUI(currentAccount);
    clearInterval(timer);
    timer = startLogOutTimer();
  }
  inputLoanAmount.value = '';
});

btnClose.addEventListener('click', function (e) {
  e.preventDefault();

  if (
    inputCloseUsername.value === currentAccount.username &&
    Number(inputClosePin.value) === currentAccount.pin
  ) {
    const index = accounts.findIndex(
      acc => acc.username === currentAccount.username
    );
    console.log(index);
    //delete account
    accounts.splice(index, 1);

    //hide UI
    containerApp.style.opacity = 0;
  }
  inputCloseUsername.value = '';
  inputClosePin.value = '';
});

let sorted = false;
btnSort.addEventListener('click', function (e) {
  e.preventDefault();
  movementDisplay(currentAccount.movements, !sorted);
  sorted = !sorted;
});

/////////////////////////////////////////////////
/////////////////////////////////////////////////
// LECTURES

const currencies = new Map([
  ['USD', 'United States dollar'],
  ['EUR', 'Euro'],
  ['GBP', 'Pound sterling'],
]);

const movements = [200, 450, -400, 3000, -650, -130, 70, 1300];

//reduse
/* const balance = movements.reduce(function (acc, cur, i, arr) {
  return acc + cur;
}, 0);
console.log(balance);

let balance2 = 0;
for (const mov of movements) balance2 += mov;
console.log(balance2);
*/

//filter
/*
const deposits = movements.filter(function (mov) {
  return mov > 0;
});

console.log(deposits);

const depositFor = [];
for (const mov of movements) if (mov > 0) depositFor.push(mov);
console.log(depositFor);

const withdraws = movements.filter(mov => {
  return mov < 0;
});
console.log(withdraws);
*/

//find

/* const firstWithdrawal = movements.find(mov => mov < 0);
console.log(firstWithdrawal); */

// FOREACH
/*for (const movement of movements) {
  if (movement > 0) {
    console.log(`Your deposite is ${movement}`);
  } else {
    console.log(`Your withdrew is ${Math.abs(movement)}`);
  }
}

console.log('----FOREACH----');
movements.forEach(function (movement) {
  if (movement > 0) {
    console.log(`Your deposite is ${movement}`);
  } else {
    console.log(`Your withdrew is ${Math.abs(movement)}`);
  }
});*/

/////////////////////////////////////////////////

/* let arr = ['a', 'b', 'c', 'd', 'e'];
console.log(arr.slice(2));
console.log(arr.splice(2)); //delete this 2 element ->
console.log(arr);
console.log(arr.reverse());
let arr2 = ['f', 'g', 'h'];
let arr3 = ['k', 'l', 'm'];
console.log(arr3.concat(arr2));
console.log([...arr2, ...arr3]);
console.log(arr2.join(' - '));

const numbers = [1, 2, 3];
console.log(numbers[0]);
console.log(numbers.at(0));
console.log(numbers[numbers.length - 1]);
console.log(numbers.slice(-1)[0]); */

//splice, foreach
/* const checkDogs = function (dogsJulia, dogsKate) {
  const juliasCopy = dogsJulia.splice(1, dogsJulia.length - 2);
  const dogs = [...juliasCopy, ...dogsKate];
  dogs.forEach(function (years, i) {
    if (years > 3) {
      console.log(`Dog number ${i + 1} is adult, and is ${years} old`);
    } else {
      console.log(`Dog number ${i + 1} is puppy, and is ${years} old`);
    }
  });
};

checkDogs([3, 5, 2, 12, 7], [5, 1, 15, 8, 3]); */

// map, filter, reduce, euto to usd
/*
const movements = [200, 450, -400, 3000, -650, -130, 70, 1300];

const euroToUsd = 1.1;

const movementsUsd = movements.map(function (mov) {
  return mov * euroToUsd;
});

// const movementsUsd = movements.map(mov => mov * euroToUsd) (arrow function)

console.log(movementsUsd);

const movementsDepWith = movements.map(function (movement, i) {
  if (movement > 0) {
    return `Movement ${i + 1}: your deposite is ${movement}`;
  } else {
    return `Movement ${i + 1}: your withdrew is ${Math.abs(movement)}`;
  }
});

console.log(movementsDepWith);

const movementsToUSD = [];
for (const mov of movements) movementsToUSD.push(mov * euroToUsd);

console.log(movementsToUSD);

const movemenstarrfunc = movements.map(
  (mov, i) => `Movements ${i + 1}: your ${mov > 0 ? 'deposited' : 'withdrew'}`
);
console.log(movemenstarrfunc);
*/

//codding chalenge 2
/* const calcAverageHumanAge = function (ages) {
  const humanAge = ages.map(age => (age <= 2 ? age * 2 : 16 + age * 4));
  console.log(humanAge);
};

calcAverageHumanAge([5, 2, 4]);*/

//codding 3
/*
const calcAverageHumanAge = function (ages) {
  const humanAge = ages.map(function (age) {
    if (age <= 2) {
      return age * 2;
    } else {
      return 16 + age * 4;
    }
  });
  //console.log(humanAge);

  const yearsAfter = humanAge.filter(function (age) {
    return age > 18;
  });
  //console.log(yearsAfter)

  const average =
    yearsAfter.reduce((acc, age) => acc + age, 0) / yearsAfter.length;
  console.log(average);
};
calcAverageHumanAge([5, 2, 4, 1, 15, 8, 3]); */

/*
const euroToUsd = 1.1;
const totalDepositUSD = movements
  .filter(mov => mov > 0)
  .map(mov => mov * euroToUsd)
  .reduce((acc, mov) => acc + mov, 0);
console.log(totalDepositUSD);*/

/* const overbalance = accounts
  .map(acc => acc.movements)
  .flat()
  .reduce((acc, mov) => acc + mov, 0);
console.log(overbalance);

const overbalance2 = accounts
  .flatMap(acc => acc.movements)
  .reduce((acc, mov) => acc + mov, 0);
console.log(overbalance);*/

/*
const bankDepositSum = accounts
  .map(acc => acc.movements)
  .flat()
  .filter(mov => mov > 0)
  .reduce((sum, cur) => sum + cur, 0);

console.log(bankDepositSum);

const numDeposit1000 = accounts
  .map(acc => acc.movements)
  .flat()
  .filter(mov => mov >= 1000).length;
console.log(numDeposit1000);

const sums = accounts
  .flatMap(acc => acc.movements)
  .reduce(
    (sums, cur) => {
      cur > 0 ? (sums.deposits += cur) : (sums.withdraws += cur);
      return sums;
    },
    { deposits: 0, withdraws: 0 }
  );
console.log(sums);
*/

/*
// this is a nice tittle -> This Is a Nice Tittle
const converteTittleText = function (tittle) {
  const expression = ['a', 'an', 'and', 'the', 'but', 'or', 'on', 'in', 'with'];

  const convertedText = tittle
    .toLowerCase()
    .split(' ')
    .map(world =>
      expression.includes(world)
        ? world
        : world[0].toUpperCase() + world.slice(1, world.length)
    )
    .join(' ');
  return convertedText;
};

console.log(converteTittleText('this is a nice tittle')); */

//challenge
/*

const dogs = [
  { weight: 22, curFood: 250, owners: ['Alice', 'Bob'] },
  { weight: 8, curFood: 200, owners: ['Matilda'] },
  { weight: 13, curFood: 275, owners: ['Sarah', 'John'] },
  { weight: 32, curFood: 340, owners: ['Michael'] },
];

//1
dogs.forEach(
  dog => (dog.recommendedFood = Math.trunc(dog.weight ** 0.75 * 28))
);

console.log(dogs);

//2

const dogSarah = dogs.find(dog => dog.owners.includes('Sarah'));

console.log(dogSarah);

if (dogSarah.curFood > dogSarah.recommendedFood) {
  console.log("Sarah's dog eat too much");
} else {
  console.log("Sarah's dog eat to little");
}

//3
let ownersEatTooLittle = [];
let ownersEatTooMuch = [];

dogs.forEach(dog =>
  dog.curFood > dog.recommendedFood
    ? ownersEatTooMuch.push(dog.owners)
    : ownersEatTooLittle.push(dog.owners)
);

console.log(ownersEatTooLittle.flat());
console.log(ownersEatTooMuch.flat());

//4.
console.log(
  `${ownersEatTooLittle.flat().join(' and ')}` + ' dogs eat too little!'
);

console.log(`${ownersEatTooMuch.flat().join(' and ')}` + ' dogs eat too much!');

//5.
console.log(dogs.some(dog => dog.curFood === dog.recommendedFood));

//6.
console.log(
  dogs.some(
    dog =>
      dog.curFood > dog.recommendedFood * 0.9 &&
      dog.curFood < dog.recommendedFood * 1.1
  )
);

//7.
const dogsEatOkay = dogs.filter(
  dog =>
    dog.curFood > dog.recommendedFood * 0.9 &&
    dog.curFood < dog.recommendedFood * 1.1
);
console.log(dogsEatOkay);

//8.
const dogsCopy = dogs
  .slice()
  .sort((a, b) => a.recommendedFood - b.recommendedFood);

console.log(dogsCopy);
*/

const num = 345456567.87;

console.log('US: ', new Intl.NumberFormat('en-Us').format(num));
console.log('Germany: ', new Intl.NumberFormat('de-DE').format(num));
console.log('Syria: ', new Intl.NumberFormat('ar-SY').format(num));

console.log(
  navigator.language,
  new Intl.NumberFormat(navigator.language).format(num)
);
